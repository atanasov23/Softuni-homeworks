let queryString = window.location.search;

let id = queryString.split('').splice(4).join('');

let id2;



window.onload = async function showComment() {

    let header = document.getElementsByClassName('header')[0];

    let res = await fetch(`http://localhost:3030/jsonstore/collections/myboard/posts/${id}`)
        .then(a => a.json())
        .then(a => a);

    header.children[1].children[0].textContent = res.userName;

    document.querySelector('h2').textContent = res.topicName;

    id2 = res._id;

    let commentResponse = await fetch(`http://localhost:3030/jsonstore/collections/myboard/comments/`)
    .then(a => a.json())
    .then(a => a);

    for(let el in commentResponse){

        if(commentResponse[el].id === id){

            document.getElementById('user-comment').innerHTML += `
            <div class="topic-name-wrapper">
            <div class="topic-name">
                <p><strong>${commentResponse[el].user}</strong> commented on <time>3/15/2021, 12:39:02 AM</time></p>
                <div class="post-content">
                    <p>${commentResponse[el].text}</p>
                </div>
            </div>
        </div>`

        }
    }
    console.log(document.querySelector('theme-name'));

}

let btn = document.querySelector('button')

btn.addEventListener('click', createComment);

async function createComment(btn) {

    let textarea = document.getElementById('comment');
let userName = document.getElementById('username');

    btn.preventDefault();

    let comment = {

        text: textarea.value,
        username: userName.value,
        id: id2
    }

    let res = await fetch(`http://localhost:3030/jsonstore/collections/myboard/comments`, {

        method: 'POST',
        headers: { 'Content-Type': 'Aplication/json' },
        body: JSON.stringify(comment)

    });

    

    document.getElementById('user-comment').innerHTML += `
    <div class="topic-name-wrapper">
    <div class="topic-name">
        <p><strong>${userName.value}</strong> commented on <time>3/15/2021, 12:39:02 AM</time></p>
        <div class="post-content">
            <p>${textarea.value}</p>
        </div>
    </div>
</div>`

document.querySelector('strong').textContent = userName.value;
}




